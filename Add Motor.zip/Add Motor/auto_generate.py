import bpy
import random


def generate_param():
    MotorParameters = {
            "mf_Head_Type" : random.choice(["mf_Head_Type_A","mf_Head_Type_B"]),
            "mf_Extension_Type_A" : random.choice(["mf_Extension_Type_1","mf_Extension_Type_2", "mf_None"]),
            "mf_Extension_Type_B" : random.choice(["mf_Extension_Type_1","mf_None"]),
            "mf_Gear_Orientation_1" : random.choice(['mf_zero','mf_Ninety', 'mf_HundredEighteen','mf_TwoHundredSeven']),
            "mf_Gear_Orientation_2" : random.choice(['mf_Ninety', 'mf_HundredEighteen','mf_TwoHundredSeven']),
            "mf_Flip" : random.choice([True,False]),
            "mf_Color_Render" : False,
            "mf_Bottom_Length" : random.randrange(0, 10),
            "mf_Sub_Bottom_Length" : random.uniform(0.6, 2),

            "mf_Lower_Gear_Dia": random.uniform(3.5, 4.5),
            "mf_Lower_Gear_Position": random.uniform( 3.6, 4.2),
            "mf_Lower_Gear_Bolt_Random" : True,
            
            "mf_Gear_Bolt_Random_B": True,
            "mf_Gear_Bolt_Nummber_B" : random.randrange(2, 3),
            "mf_Type_B_Height_1" : random.uniform(6.3, 8),
            "mf_Type_B_Height_2" : random.uniform(2, 6),
                        
            "mf_Upper_Gear_Dia": random.uniform(5, 6.5),
            "mf_Upper_Bolt_Nummber": random.randrange(1, 3),
            "mf_Upper_Gear_Bolt_Random" : True,

            "mf_Bit_Type" : random.choice(['mf_Bit_Torx','mf_Bit_Slot','mf_Bit_Cross']),
            "mf_Bolt_Orientation": "mf_all_random",
            }
    return MotorParameters

def create_motor(number: int, **data):
    for i in range(number):
        param = generate_param()
        for key, value in data.items():
            param[key] = value
            motor = bpy.ops.mesh.add_motor(**param)
            
        
            
if __name__ == "__main__":
    num = 5
    data = {}
    # Set parameter that should be manuelly modified
    data['save_path']="F:/blender_test/" # Add other param like this
    create_motor(num, **data)    
               
        
